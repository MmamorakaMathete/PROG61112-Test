import java.util.Scanner;

public class RunApplication {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Enter console type:");
        String consoleType = input.nextLine();

        System.out.println("Enter store name:");
        String store = input.nextLine();

        System.out.println("Enter total sales:");
        int totalSales = input.nextInt();

        ConsoleSales sales = new ConsoleSales(
                consoleType,
                store,
                totalSales
        );

        System.out.println("\n--- Console Sales Report ---");
        sales.printReport();

        input.close();
    }
}
